## V1.0

- 使用overlayfs在initramfs实现的Read-Only文件系统
- 使用niun/root-ro @ gist.github.com
- 使用install.sh安装，uninstall.sh恢复
- 使用switch.sh切换状态（需要重启）


翁喆 2016.12.11
